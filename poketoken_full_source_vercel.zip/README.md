
PokeToken — Full Source (GitHub -> Vercel)
- Tabs: Main, Stake (inventory), Shop, Referral, Leaderboard, Season, Daily
- 30 avatars (PNG) + manifest
Deploy: npm i && npm run build (Output: dist)
