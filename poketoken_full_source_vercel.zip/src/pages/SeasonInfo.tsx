
import React from 'react'
export default function SeasonInfo(){
  return <div className="card">
    <div style={{fontWeight:800,fontSize:18}}>Season 1 — 100 SOL pool</div>
    <div className="small">Web3 Telegram Mini App. PokeToken will become a real token before season end. Sponsors only real/verified (e.g., Solana ecosystem).</div>
  </div>
}
