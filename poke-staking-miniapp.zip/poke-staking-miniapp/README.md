# Monstrų Staking — Telegram Mini App (Frontend + Server + Bot)

## Struktūra
- `frontend/` — React + Vite Mini App (Telegram WebApp SDK).
- `server/` — Node.js (Express + SQLite + Telegraf). Saugo progresą, tikrina Telegram initData.
- `.env.example` — serverio kintamieji.

## Greitas startas (lokaliai)
1) **Frontend**
```bash
cd frontend
npm i
npm run dev
# http://localhost:5173
```
2) **Server**
```bash
cd server
npm i
cp ../.env.example .env   # įrašyk savo BOT_TOKEN ir URL
npm run start             # API ant 8080, taip pat paleidžiamas bot'as
```
3) **Telegram**
- @BotFather → /newbot → pasiimk **BOT_TOKEN**.
- @BotFather → Edit Bot → **Web App** → Web App URL = tavo frontend URL (lokaliai gali naudoti tunelį kaip smee/ngrok; produkcijai – Vercel).
- Atidaryk botą telefone → /start → mygtukas „🎮 Žaisti“.

## Deploy
- **Frontend** → Vercel/Netlify/Cloudflare Pages. Nustatyk `VITE_API_BASE` į tavo API URL.
- **Server** → Railway/Render/Fly/any VPS. `sqlite` failas `db.sqlite` laikomas serveryje.

## Admin
- `GET /api/admin/stats?key=ADMIN_KEY`
- ADMIN_KEY nurodyk `.env` faile, laikyk paslaptyje (tik tu).

## Saugumas
- Kiekviena užklausa turi `X-TG-INIT-DATA` (Telegram WebApp initData). Serveris patikrina HMAC pagal tavo `BOT_TOKEN`.
- Žaidėjų duomenys rišami prie `tg_id`. Tik tu turi admin raktą.
