\
import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import crypto from 'crypto'
import sqlite3 from 'sqlite3'
import { open } from 'sqlite'
import { Telegraf, Markup } from 'telegraf'

const {
  PORT = 8080,
  FRONTEND_ORIGIN = '*',
  BOT_TOKEN,
  WEBAPP_URL = 'http://localhost:5173',
  ADMIN_KEY = 'changeme_admin'
} = process.env

if (!BOT_TOKEN) {
  console.error('ERROR: BOT_TOKEN env is required'); process.exit(1)
}

const app = express()
app.use(cors({ origin: FRONTEND_ORIGIN, credentials: true }))
app.use(express.json())

// --- Telegram WebApp initData validation ---
function parseInitData(initData) {
  const url = new URLSearchParams(initData)
  const data = {}
  for (const [k,v] of url.entries()) data[k]=v
  return data
}
function checkInitData(initData) {
  try {
    const data = parseInitData(initData)
    const hash = data.hash
    delete data.hash
    const sorted = Object.keys(data).sort().map(k=>`${k}=${data[k]}`).join('\n')
    const secretKey = crypto.createHmac('sha256', 'WebAppData').update(BOT_TOKEN).digest()
    const calc = crypto.createHmac('sha256', secretKey).update(sorted).digest('hex')
    return calc === hash ? data : null
  } catch(e) {
    return null
  }
}

// --- DB ---
const db = await open({ filename: './db.sqlite', driver: sqlite3.Database })
await db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tg_id TEXT UNIQUE, first_name TEXT, created_at INTEGER,
  level INTEGER DEFAULT 1, xp INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS cards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id INTEGER, code TEXT, name TEXT, emoji TEXT,
  rate REAL, capacity REAL, unlocked_level INTEGER DEFAULT 1,
  staked INTEGER DEFAULT 0,
  FOREIGN KEY(owner_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS slots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id INTEGER, slot_index INTEGER, card_id INTEGER,
  last_claim_ts INTEGER DEFAULT 0,
  FOREIGN KEY(owner_id) REFERENCES users(id),
  FOREIGN KEY(card_id) REFERENCES cards(id)
);
`)

// Seed definitions (server-side catalog)
const CATALOG = [
  { code:'sparko', name:'Sparko', emoji:'⚡️', rate:3, capacity:72, unlock:1 },
  { code:'embero', name:'Embero', emoji:'🔥', rate:4, capacity:96, unlock:5 },
  { code:'aquaff', name:'Aquaff', emoji:'💧', rate:5, capacity:120, unlock:10 },
  { code:'verdant', name:'Verdant', emoji:'🌿', rate:6, capacity:144, unlock:15 }
]

async function ensureUser(tgUser){
  const now = Math.floor(Date.now()/1000)
  let u = await db.get('SELECT * FROM users WHERE tg_id=?', [tgUser.id])
  if (!u) {
    await db.run('INSERT INTO users (tg_id, first_name, created_at, level, xp) VALUES (?,?,?,?,?)',
      [String(tgUser.id), tgUser.first_name||'', now, 1, 0])
    u = await db.get('SELECT * FROM users WHERE tg_id=?', [tgUser.id])
    // create 5 slots
    for (let i=0;i<5;i++) await db.run('INSERT INTO slots (owner_id, slot_index, last_claim_ts) VALUES (?,?,?)', [u.id, i, now])
    // give starter card
    const starter = CATALOG.find(c=>c.unlock===1)
    await db.run('INSERT INTO cards (owner_id, code, name, emoji, rate, capacity, unlocked_level, staked) VALUES (?,?,?,?,?,?,?,0)',
      [u.id, starter.code, starter.name, starter.emoji, starter.rate, starter.capacity, starter.unlock])
  }
  return u
}
async function getUserByInit(initData) {
  const data = checkInitData(initData)
  if (!data) return null
  const user = JSON.parse(data.user) // Telegram user object
  const u = await ensureUser(user)
  return {u, tg: user}
}
function nextXpFor(level){ return level * 100 }

// Helpers for staking accrual
function computeAccrued(lastTs, rate, capacity){
  const now = Math.floor(Date.now()/1000)
  const hours = Math.max(0, (now - lastTs) / 3600)
  const accrued = Math.min(capacity, Math.floor(hours * rate))
  const pct = Math.floor(100 * Math.min(1, (hours * rate) / capacity))
  return { accrued, progressPct: pct }
}
async function getSlots(owner_id){
  const rows = await db.all('SELECT s.*, c.name, c.emoji, c.rate, c.capacity FROM slots s LEFT JOIN cards c ON s.card_id=c.id WHERE s.owner_id=? ORDER BY slot_index', [owner_id])
  return rows.map(r=>{
    if (!r.card_id) return { card:null, progressPct:0, accrued:0 }
    const { accrued, progressPct } = computeAccrued(r.last_claim_ts, r.rate, r.capacity)
    return { card: { id:r.card_id, name:r.name, emoji:r.emoji, rate:r.rate, capacity:r.capacity }, progressPct, accrued }
  })
}
async function getCards(owner_id){
  const rows = await db.all('SELECT * FROM cards WHERE owner_id=?', [owner_id])
  return rows.map(r=>({ id:r.id, code:r.code, name:r.name, emoji:r.emoji, rate:r.rate, capacity:r.capacity, staked: !!r.staked }))
}

// --- Routes ---
app.get('/api/profile', async (req,res)=>{
  const initData = req.header('X-TG-INIT-DATA')||''
  const auth = await getUserByInit(initData)
  if (!auth) return res.status(401).json({ error:'unauthorized' })
  const { u } = auth
  const next_xp = nextXpFor(u.level)
  // ensure unlocks
  const unlocked = CATALOG.filter(c=>c.unlock<=u.level)
  for (const c of unlocked) {
    const owned = await db.get('SELECT id FROM cards WHERE owner_id=? AND code=?', [u.id, c.code])
    if (!owned) {
      await db.run('INSERT INTO cards (owner_id, code, name, emoji, rate, capacity, unlocked_level, staked) VALUES (?,?,?,?,?,?,?,0)',
        [u.id, c.code, c.name, c.emoji, c.rate, c.capacity, c.unlock])
    }
  }
  // next unlock level
  const next = CATALOG.filter(c=>c.unlock>u.level).sort((a,b)=>a.unlock-b.unlock)[0]
  res.json({ id:u.id, level:u.level, xp:u.xp, next_xp, next_unlock_level: next?.unlock || null })
})

app.get('/api/slots', async (req,res)=>{
  const initData = req.header('X-TG-INIT-DATA')||''
  const auth = await getUserByInit(initData)
  if (!auth) return res.status(401).json({ error:'unauthorized' })
  const slots = await getSlots(auth.u.id)
  res.json({ slots })
})

app.get('/api/cards', async (req,res)=>{
  const initData = req.header('X-TG-INIT-DATA')||''
  const auth = await getUserByInit(initData)
  if (!auth) return res.status(401).json({ error:'unauthorized' })
  const cards = await getCards(auth.u.id)
  res.json({ cards })
})

app.post('/api/stake', async (req,res)=>{
  const initData = req.header('X-TG-INIT-DATA')||''
  const auth = await getUserByInit(initData)
  if (!auth) return res.status(401).json({ error:'unauthorized' })
  const { slotIndex, cardId } = req.body||{}
  const slot = await db.get('SELECT * FROM slots WHERE owner_id=? AND slot_index=?', [auth.u.id, slotIndex])
  if (!slot) return res.json({ ok:false, error:'slot not found' })
  const card = await db.get('SELECT * FROM cards WHERE id=? AND owner_id=?', [cardId, auth.u.id])
  if (!card) return res.json({ ok:false, error:'card not found' })
  if (card.staked) return res.json({ ok:false, error:'card already staked' })
  await db.run('UPDATE slots SET card_id=?, last_claim_ts=? WHERE id=?', [card.id, Math.floor(Date.now()/1000), slot.id])
  await db.run('UPDATE cards SET staked=1 WHERE id=?', [card.id])
  res.json({ ok:true })
})

app.post('/api/claim', async (req,res)=>{
  const initData = req.header('X-TG-INIT-DATA')||''
  const auth = await getUserByInit(initData)
  if (!auth) return res.status(401).json({ error:'unauthorized' })
  const { slotIndex } = req.body||{}
  const row = await db.get('SELECT s.*, c.rate, c.capacity FROM slots s JOIN cards c ON s.card_id=c.id WHERE s.owner_id=? AND s.slot_index=?', [auth.u.id, slotIndex])
  if (!row) return res.json({ ok:false, error:'slot empty or not found' })
  const { accrued } = computeAccrued(row.last_claim_ts, row.rate, row.capacity)
  if (accrued <= 0) return res.json({ ok:false, error:'nothing to claim' })
  const now = Math.floor(Date.now()/1000)
  await db.run('UPDATE users SET xp = xp + ? WHERE id=?', [accrued, auth.u.id])
  await db.run('UPDATE slots SET last_claim_ts=? WHERE id=?', [now, row.id])
  // level up if xp exceeded
  const u = await db.get('SELECT * FROM users WHERE id=?', [auth.u.id])
  let leveled = false
  while (u.xp >= (u.level * 100)) {
    u.xp -= (u.level * 100); u.level += 1; leveled = true
  }
  if (leveled) await db.run('UPDATE users SET level=?, xp=? WHERE id=?', [u.level, u.xp, u.id])
  res.json({ ok:true, gained: accrued, levelUp: leveled })
})

// Admin: quick stats
app.get('/api/admin/stats', async (req,res)=>{
  const key = req.query.key
  if (key !== ADMIN_KEY) return res.status(401).json({ error:'unauthorized' })
  const users = await db.get('SELECT COUNT(*) as c FROM users')
  const cards = await db.get('SELECT COUNT(*) as c FROM cards')
  const staked = await db.get('SELECT COUNT(*) as c FROM cards WHERE staked=1')
  res.json({ users:users.c, cards:cards.c, staked:staked.c })
})

// --- Telegram bot ---
const bot = new Telegraf(BOT_TOKEN)
bot.start((ctx)=>{
  return ctx.reply('Monstrų Staking', Markup.keyboard([
    [Markup.button.webApp('🎮 Žaisti', WEBAPP_URL)]
  ]).resize())
})
bot.launch().then(()=> console.log('Bot running'))

process.once('SIGINT', () => bot.stop('SIGINT'))
process.once('SIGTERM', () => bot.stop('SIGTERM'))

app.listen(PORT, ()=> console.log('API on http://localhost:'+PORT))
